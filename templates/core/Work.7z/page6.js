// Pie Chart
if ($('#pie-chart').length) {

  var data_pie = [];
  var series = 5;
  for (var i = 0; i < series; i++) {
    data_pie[i] = {
      label : "Series" + (i + 1),
      data : Math.floor(Math.random() * 100) + 1
    }
  }
  data_pie[0].label = "Emirates"
  data_pie[1].label = "Air France"
  data_pie[2].label = "KLM"
  data_pie[3].label = "Lufthansa"
  data_pie[4].label = "Alitalia"

  $.plot($("#pie-chart"), data_pie, {
    series : {
      pie : {
        show : true,
        innerRadius : 0.5,
        radius : 1,
        label : {
          show : true,
          radius : 2 / 3,
          formatter : function(label, series) {
            return '<div style="font-size:11px;text-align:center;padding:4px;color:white;">' +  Math.round(series.percent) + '%</div>';
          },
          threshold : 0.1
        }
      }
    },
    legend : {
      show : true,
      noColumns : 1, // number of colums in legend table
      labelFormatter : null, // fn: string -> string
      labelBoxBorderColor : "#000", // border color for the little label boxes
      container : null, // container (as jQuery object) to put legend in, null means default on top of graph
      position : "ne", // position of default legend container within plot
      margin : [5, 10], // distance from grid edge to default legend container within plot
      backgroundColor : "#efefef", // null means auto-detect
      backgroundOpacity : 1 // set to 0 to avoid background
    },
    grid : {
      hoverable : true,
      clickable : true
    },
  });

}

// Pie Chart Ends

/* bar chart */

if ($("#bar-chart").length) {

  var data1 = [];
  for (var i = 0; i <= 12; i += 1)
    data1.push([i, parseInt(Math.random() * 30)]);

  var data2 = [];
  for (var i = 0; i <= 12; i += 1)
    data2.push([i, parseInt(Math.random() * 30)]);

  var data3 = [];
  for (var i = 0; i <= 12; i += 1)
    data3.push([i, parseInt(Math.random() * 30)]);

  var ds = new Array();

  ds.push({
    label: 'Emirates',
    data : data1,
    bars : {
      show : true,
      barWidth : 0.8,
      order : 1
    }
  });
  ds.push({
    data : data2,
    bars : {
      show : true,
      barWidth : 0.8,
      order : 2
    }
  });
  ds.push({
    data : data3,
    bars : {
      show : true,
      barWidth : 0.8,
      order : 3
    }
  });

  //Display graph
  $.plot($("#bar-chart"), ds, {
    colors : ["#AA3452", "#123FAC", "#666", "#BBB"],
    grid : {
      show : true,
      hoverable : true,
      clickable : true,
      tickColor : "#eee",
      borderWidth : 0,
      borderColor : "#FA23453",
    },
    legend : true,
    tooltip : true,
    tooltipOpts : {
      content : "<b>%x</b> = <span>%y</span>",
      defaultTheme : false
    }

  });

}

/* end bar chart */
